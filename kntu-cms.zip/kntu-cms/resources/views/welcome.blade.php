@extends('custom-layouts.admin-layout')

@section('title', 'Dashboard')

@section('mainContent')
    <div>
        welcome here
    </div>
@endsection
