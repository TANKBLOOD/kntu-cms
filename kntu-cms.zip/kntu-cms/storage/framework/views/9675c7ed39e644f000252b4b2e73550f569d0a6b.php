<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('mainContent'); ?>
    <div>
        welcome here
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\kntu-cms\kntu-cms\resources\views/welcome.blade.php ENDPATH**/ ?>